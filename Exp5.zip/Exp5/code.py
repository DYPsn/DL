# Install and import
!pip install -q torchvision

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from google.colab import files
from PIL import Image
import matplotlib.pyplot as plt

device = "cuda" if torch.cuda.is_available() else "cpu"
print("Using:", device)

# -----------------------------
# Define CNN model
# -----------------------------
class BasicCNN(nn.Module):
    def __init__(self):
        super(BasicCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, 3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
        self.pool = nn.MaxPool2d(2,2)
        self.fc1 = nn.Linear(64*7*7, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 64*7*7)
        x = F.relu(self.fc1(x))
        return self.fc2(x)

model = BasicCNN().to(device)

# -----------------------------
# Load MNIST dataset
# -----------------------------
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,))
])

trainset = torchvision.datasets.MNIST(root="./data", train=True, download=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=64, shuffle=True)

# -----------------------------
# Train for a few batches (fast)
# -----------------------------
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
criterion = nn.CrossEntropyLoss()

print("Training model (8–10 seconds)...")

model.train()
for batch_idx, (data, target) in enumerate(trainloader):
    if batch_idx == 200:   # Train only 200 batches → fast & accurate
        break
    data, target = data.to(device), target.to(device)

    optimizer.zero_grad()
    output = model(data)
    loss = criterion(output, target)
    loss.backward()
    optimizer.step()

print("✔️ Training complete!")

model.eval()

# -----------------------------
# Upload Image for prediction
# -----------------------------
uploaded = files.upload()
image_path = list(uploaded.keys())[0]
img = Image.open(image_path).convert("L")

# Show image
plt.imshow(img, cmap="gray")
plt.axis("off")
plt.show()

# Preprocess like MNIST
transform_img = transforms.Compose([
    transforms.Resize((28,28)),
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,))
])

input_tensor = transform_img(img).unsqueeze(0).to(device)

# Predict
with torch.no_grad():
    output = model(input_tensor)
    pred = output.argmax(1).item()

confidence = torch.softmax(output,1)[0][pred].item()

print(f"🔢 Predicted Digit: {pred}")
print(f"💯 Confidence: {confidence*100:.2f}%")
