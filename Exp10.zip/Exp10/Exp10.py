import tensorflow as tf
import numpy as np
from tensorflow.keras.applications import vgg19
from tensorflow.keras.preprocessing import image
from PIL import Image
from google.colab import files

uploaded = files.upload()

# ---- Load and preprocess image ----
def load_img(path):
    img = image.load_img(path, target_size=(256, 256))  # smaller = faster
    img = image.img_to_array(img)
    img = np.expand_dims(img, axis=0)
    return vgg19.preprocess_input(img)

def deprocess(x):
    x = x.reshape((256, 256, 3))
    x[:, :, 0] += 103.939
    x[:, :, 1] += 116.779
    x[:, :, 2] += 123.68
    x = x[:, :, ::-1]
    return np.clip(x, 0, 255).astype("uint8")

# ---- Input paths ----
content = load_img("content.jpg")
style = load_img("style.jpg")

# ---- Load VGG19 ----
model = vgg19.VGG19(weights="imagenet", include_top=False)
layers = dict([(layer.name, layer.output) for layer in model.layers])

feat_extractor = tf.keras.Model(
    inputs=model.input,
    outputs=[layers["block5_conv2"], layers["block1_conv1"]]
)

content_feat, style_feat = feat_extractor(content)
gen_img = tf.Variable(content, dtype=tf.float32)

# ---- Optimizer ----
opt = tf.optimizers.Adam(learning_rate=0.03)

style_weight, content_weight = 1e-2, 1e3

# ---- Gram Matrix ----
def gram_matrix(x):
    x = tf.squeeze(x)
    x = tf.reshape(x, [-1, x.shape[-1]])
    return tf.matmul(x, x, transpose_a=True)

# ---- Training Loop ----
for i in range(80):  # reduced to 80 iterations
    with tf.GradientTape() as tape:
        c_feat, s_feat = feat_extractor(gen_img)
        c_loss = tf.reduce_mean((c_feat - content_feat)**2)
        s_loss = tf.reduce_mean((gram_matrix(s_feat) - gram_matrix(style_feat))**2)
        loss = content_weight * c_loss + style_weight * s_loss

    grad = tape.gradient(loss, gen_img)
    opt.apply_gradients([(grad, gen_img)])
    gen_img.assign(tf.clip_by_value(gen_img, -128.0, 128.0))

    if i % 10 == 0:
        print(f"Step {i}, Loss: {loss.numpy():.2f}")

# ---- Save result ----
final = deprocess(gen_img.numpy())
Image.fromarray(final).save("stylized.jpg")
print("✅ Done! Saved as stylized.jpg")
